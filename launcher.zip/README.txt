PLEASE EXTRACT THIS TO AN EMPTY FOLDER, CUZ IT WILL STORE MODDED STUFF ON THE FOLDER.

If you have 1 braincell and don't know how to open the launcher, simply open it like you usually do when you open stuff idk

make sure you have java 17 in your system.




setup guide if ur noob: https://setup.skidded.works
